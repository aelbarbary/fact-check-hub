from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Fact
from .serializers import FactSerializer
from .services.langchain_service import LangChainService

class FactViewSet(viewsets.ModelViewSet):
    queryset = Fact.objects.all()
    serializer_class = FactSerializer
    langchain_service = LangChainService()

    @action(detail=False, methods=['post'])
    def search(self, request):
        query = request.data.get('query')
        if not query:
            return Response(
                {'error': 'Query parameter is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            results = self.langchain_service.search_facts(query)
            return Response({'results': results})
        except Exception as e:
            return Response(
                {'error': str(e)}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )