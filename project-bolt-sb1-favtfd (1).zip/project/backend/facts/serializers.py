from rest_framework import serializers
from .models import Fact

class FactSerializer(serializers.ModelSerializer):
    class Meta:
        model = Fact
        fields = ['id', 'statement', 'is_verified', 'verification_status', 
                 'source', 'category', 'date_added']