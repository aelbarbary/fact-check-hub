from django.db import models

class Fact(models.Model):
    statement = models.TextField()
    is_verified = models.BooleanField(default=False)
    verification_status = models.CharField(
        max_length=10,
        choices=[
            ('pending', 'Pending'),
            ('verified', 'Verified'),
            ('false', 'False'),
        ],
        default='pending'
    )
    source = models.CharField(max_length=255, blank=True)
    category = models.CharField(max_length=100)
    date_added = models.DateTimeField(auto_now_add=True)
    s3_document_key = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.statement[:50]}..."