import boto3
from django.conf import settings

class S3Service:
    def __init__(self):
        self.s3_client = boto3.client(
            's3',
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            region_name=settings.AWS_S3_REGION_NAME
        )
        self.bucket_name = settings.AWS_STORAGE_BUCKET_NAME

    def get_document_content(self, key):
        try:
            response = self.s3_client.get_object(
                Bucket=self.bucket_name,
                Key=key
            )
            return response['Body'].read().decode('utf-8')
        except Exception as e:
            print(f"Error retrieving document from S3: {str(e)}")
            return None

    def list_documents(self):
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name
            )
            return [item['Key'] for item in response.get('Contents', [])]
        except Exception as e:
            print(f"Error listing documents from S3: {str(e)}")
            return []