from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from .s3_service import S3Service

class LangChainService:
    def __init__(self):
        self.s3_service = S3Service()
        self.embeddings = OpenAIEmbeddings()
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )

    def create_document_index(self):
        documents = []
        for doc_key in self.s3_service.list_documents():
            content = self.s3_service.get_document_content(doc_key)
            if content:
                splits = self.text_splitter.split_text(content)
                documents.extend(splits)

        if documents:
            return FAISS.from_texts(documents, self.embeddings)
        return None

    def search_facts(self, query, k=5):
        index = self.create_document_index()
        if not index:
            return []
        
        results = index.similarity_search(query, k=k)
        return [doc.page_content for doc in results]